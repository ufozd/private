#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include "ros_machine.hpp"

extern ros_machine *return_ros(void);
ros_machine *machineP;

#define SW1_PIN GET_PIN(C, 9)
#define SW2_PIN GET_PIN(C, 8)
#define SW3_PIN GET_PIN(C, 7)
#define SW4_PIN GET_PIN(C, 6)
#define SW5_PIN GET_PIN(B, 15)
#define SW6_PIN GET_PIN(B, 14)
#define SW7_PIN GET_PIN(B, 13)
#define SW8_PIN GET_PIN(B, 12)

#define LONG_TIME_SET          (5 * 12)  // 1.2s
#define LONG_TIME_RELEASE      (2)       // 20*2 ms

uint16_t doubunce_ctrl = 0;
uint8_t flag_bu_ctrl = 0;

uint16_t doubunce_reset = 0;
uint8_t flag_bu_reset = 0;

static uint8_t bu_ctrl(void)
{
    return rt_pin_read(SW1_PIN);
}

static uint8_t bu_reset(void)
{
    return rt_pin_read(SW2_PIN);
}

static void button_task(void* parameter)
{
    rt_pin_mode(SW1_PIN, PIN_MODE_INPUT);
    rt_pin_mode(SW2_PIN, PIN_MODE_INPUT);
    rt_pin_mode(SW3_PIN, PIN_MODE_INPUT);
    rt_pin_mode(SW4_PIN, PIN_MODE_INPUT);
    rt_pin_mode(SW5_PIN, PIN_MODE_INPUT);
    rt_pin_mode(SW6_PIN, PIN_MODE_INPUT);
    rt_pin_mode(SW7_PIN, PIN_MODE_INPUT);
    rt_pin_mode(SW8_PIN, PIN_MODE_INPUT);
    rt_thread_delay(20);
    machineP = return_ros();
    while(1)
    {
        rt_thread_delay(20);
        
        if(!bu_ctrl()) // ����
        {
            if(!flag_bu_ctrl)
            {
                if(doubunce_ctrl++ >= LONG_TIME_SET)
                {
                    flag_bu_ctrl = 1;
                    doubunce_ctrl = 0;
                    
                    // ��������
                    if(machineP->getState() == ROS_READY)
                    {
                       machineP->run();
                    }
                    else if(machineP->getState() == ROS_SUSPEND)
                    {
                        machineP->recover();
                    }
                    
                    rt_kprintf("this is start\n");
                }
            }
            else
            {
                doubunce_ctrl = 0;
            }
            
        }
        else
        {
            if(flag_bu_ctrl)
            {
                if(doubunce_ctrl++ >= LONG_TIME_RELEASE)
                {
                    flag_bu_ctrl = 0;
                    doubunce_ctrl = 0;
                    
                    // �����ͷŴ���
                    machineP->suspend();
                    rt_kprintf("this is stop\n");
                }
            }
            else
            {
                doubunce_ctrl = 0;
            }
        }
        
        if(!bu_reset()) // ����
        {
            if(!flag_bu_reset)
            {
                if(doubunce_reset++ >= LONG_TIME_SET)
                {
                    flag_bu_reset = 1;
                    doubunce_reset = 0;
                    
                    // ��������
                    machineP->reset();
                    rt_kprintf("this is reset\n");
                }
            }
            else
            {
                doubunce_reset = 0;
            }
            
        }
        else
        {
            if(flag_bu_reset)
            {
                if(doubunce_reset++ >= LONG_TIME_RELEASE)
                {
                    flag_bu_reset = 0;
                    doubunce_reset = 0;
                    
                    // �����ͷŴ���
                }
            }
            else
            {
                doubunce_reset = 0;
            }
        }
    }
}

static int button_task_init(void)
{
    rt_thread_t button_thread = rt_thread_create("buttonTask", button_task, RT_NULL, 512, 12, 5);
    if (button_thread != RT_NULL)
    {
        rt_thread_startup(button_thread);
        return 0;
    }
    
    return 1;
}
INIT_APP_EXPORT(button_task_init);
