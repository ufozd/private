#ifndef __MOTOR_MODBUSCMD_H__
#define __MOTOR_MODBUSCMD_H__

#include <stdint.h>

#define mdEVENT_OK    (1 << 3)
#define mdEVENT_FAIL  (1 << 5)

#define MOTOR_LEFT_UP_DIR     -1        // 0�ŵ��
#define MOTOR_LEFT_DN_DIR     1         // 1�ŵ��
#define MOTOR_RIGHT_UP_DIR    -1        // 2�ŵ��
#define MOTOR_RIGHT_DN_DIR    1         // 3�ŵ��

extern int8_t motor_setSpeedPer_MB(int8_t Per, uint8_t role);
extern int8_t motor_close_MB(uint8_t role);
extern int8_t motor_get_vbus_MB(uint8_t role);
extern int8_t motor_get_err_MB(uint8_t role);
extern int8_t motor_get_state_MB(uint8_t role);
extern int8_t motor_get_stateAll_MB(uint8_t role);

#endif
