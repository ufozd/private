#include "wireless2_4G.h"
#include <nrf24l01.h>
#include "drv_spi.h"

wireLess_type wireless;     // ����һ������

#if (PKG_NRF24L01_DEMO_CE_PIN < 0)
#error Please specify a valid pin
#endif

#ifdef PKG_NRF24L01_DEMO_ROLE_PTX
    #define NRF24_DEMO_ROLE     ROLE_PTX
    #define NRF24_DEMO_SEND_INTERVAL        PKG_NRF24L01_DEMO_INTERVAL_SEND
#else
    #define NRF24_DEMO_ROLE     ROLE_PRX
#endif

#define NRF24_DEMO_SPI_DEV_NAME         PKG_NRF24L01_DEMO_SPI_DEV_NAME
#define NRF24_DEMO_CE_PIN               PKG_NRF24L01_DEMO_CE_PIN
#define NRF24_DEMO_IRQ_PIN              PKG_NRF24L01_DEMO_IRQ_PIN

static void rx_ind(nrf24_t nrf24, uint8_t *data, uint8_t len, int pipe)
{
    /* �������ݺ���ֱ�ӷŵ������� */
    //rt_mq_send(&wireless.mq, data, len);
}

static void tx_done(nrf24_t nrf24, int pipe)
{
    static int cnt = 0;
    static char tbuf[32];

    cnt++;

    /*! Here just want to tell the user when the role is ROLE_PTX
    the pipe have no special meaning except indicating (send) FAILED or OK 
        However, it will matter when the role is ROLE_PRX*/
    if (nrf24->cfg.role == ROLE_PTX)
    {
        if (pipe == NRF24_PIPE_NONE)
            rt_kprintf("tx_done failed");
        else
            rt_kprintf("tx_done ok");
    }
    else
    {
        rt_kprintf("tx_done ok");
    }

#ifdef PKG_NRF24L01_DEMO_ROLE_PTX
    rt_thread_mdelay(NRF24_DEMO_SEND_INTERVAL);
#endif
}

const static struct nrf24_callback _cb = {
    .rx_ind = rx_ind,
    .tx_done = tx_done,
};

static void thread_entry(void *param)
{
    nrf24_t nrf24;
    rt_hw_spi_device_attach("spi1", "spi10", GPIOC, GPIO_PIN_12);
    nrf24 = nrf24_default_create(NRF24_DEMO_SPI_DEV_NAME, NRF24_DEMO_CE_PIN, NRF24_DEMO_IRQ_PIN, &_cb, NRF24_DEMO_ROLE);

    //wireless_init();
    //nrf24_set_Rxmode
    while (1)
    {
        nrf24_run(nrf24);
        if(!nrf24->flags.using_irq)
            rt_thread_mdelay(10);
    }
    
}

static int nrf24l01_sample_init(void)
{
    rt_thread_t thread;

    thread = rt_thread_create("nrf", thread_entry, RT_NULL, 1024, RT_THREAD_PRIORITY_MAX/2, 20);
    rt_thread_startup(thread);

    return RT_EOK;
}

//INIT_APP_EXPORT(nrf24l01_sample_init);


static void wireless_entry(void *param)
{
    uint8_t rx[32];
    while (1)
    {
        if(rt_mq_recv(&wireless.mq, &rx, sizeof(rx), RT_WAITING_FOREVER) == RT_EOK)
        {
            rt_kprintf("rex %s", rx);
        }
    }
}

static int wireless_sample_init(void)
{
    rt_thread_t thread;

    thread = rt_thread_create("wireless", wireless_entry, RT_NULL, 512, 10, 20);
    rt_thread_startup(thread);

    return RT_EOK;
}

//INIT_APP_EXPORT(wireless_sample_init);

void wireless_init(void)
{
    uint8_t result;
    result = rt_mq_init(&wireless.mq, "wire", wireless.msg_pool, MES_LENGTH, MES_SIZE, RT_IPC_FLAG_FIFO);
    if(RT_EOK == result)
    {
        rt_kprintf("wireless is ok \n");
    }
        
}
