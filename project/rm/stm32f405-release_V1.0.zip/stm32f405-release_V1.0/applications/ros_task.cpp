#include "ros_task.hpp"

#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>

#include "ros_machine.hpp"
#include <stdlib.h>

ros_machine *machine;

ros_action_t Taction;
ros_actionDispatch_t Tdispatch;
ros_drive_t L_leftup;
ros_drive_t L_leftdn;
ros_drive_t L_rightup;
ros_drive_t L_rgihtdn;

ros_sensor_t S_leftup;
ros_sensor_t S_leftdn;
ros_sensor_t S_rightup;
ros_sensor_t S_rightdn;

angleVal aVal;
angleVal calVal;
angleVal conVal;
ros_angleMemory *aMem;

extern float adcUpLeftAngle;
extern float adcUpRightAngle;
extern float adcDnLeftAngle;
extern float adcDnRightAngle;

ros_machine *return_ros(void)
{
    return machine;
}

static void ros_task(void* parameter)
{
    /* ������������ */
    ros_drive_factory_t driveGet = new class ros_drive_factory;                                 
    L_leftup = driveGet->ros_drive_create(BRUSHLESSMOTOR, 1);
    L_leftdn = driveGet->ros_drive_create(BRUSHLESSMOTOR, 2);
    L_rightup = driveGet->ros_drive_create(BRUSHLESSMOTOR, 3);
    L_rgihtdn = driveGet->ros_drive_create(BRUSHLESSMOTOR, 4);
    
    S_leftup = driveGet->ros_sensor_create(ADC_MEM, "S_leftup", &adcUpLeftAngle);
    S_leftdn = driveGet->ros_sensor_create(ADC_MEM, "S_leftdn", &adcDnLeftAngle);
    S_rightup = driveGet->ros_sensor_create(ADC_MEM, "S_rightup", &adcUpRightAngle);
    S_rightdn = driveGet->ros_sensor_create(ADC_MEM, "S_rightdn", &adcDnRightAngle);
    delete driveGet;
    
    if(L_leftup == RT_NULL || L_leftdn == RT_NULL || S_leftup == RT_NULL || S_leftdn == RT_NULL)
    {
        rt_kprintf("derive factory was failed to create drive\r\n");
    }
    
    /* �����ȵ�ģ�� */
    ros_foot *leftFoot = new ros_foot(L_leftup, L_leftdn, S_leftup, S_leftdn);
    ros_foot *rightFoot = new ros_foot(L_rightup, L_rgihtdn, S_rightup, S_rightdn);
    if(leftFoot == RT_NULL || rightFoot == RT_NULL)
    {
        rt_kprintf("foot was failed to create\r\n");
    }
    
    /* ��������ģ�� */
    machine = new ros_machine(leftFoot, rightFoot);
    
    /* ������������ */
    ros_walkActionFaster *walkFaster = new ros_walkActionFaster();   // ����һ�����߶���
    Taction = walkFaster->createAction();
    delete walkFaster;
   
    Tdispatch = new ros_actionDispatch();
    Tdispatch->loadAction(Taction);                                    // ���Է�����   
    rt_kprintf("\n%s\n", Tdispatch->getActionDes());    
   
    aMem = new ros_angleMemory();
    
    machine->loadAction(Taction);                                    // ���Ӷ���������
    //machine->setTest(0);                                             // ����ģ�����
    machine->setMode(ROS_TEST);                                      // ������������ģʽ
    machine->enter();                                                // �������õĶ���
    //machine->run();                                                  // ����
    //machine->suspend();                                              // �������״̬
    
    while(1)
    {
        aVal.angle[0] = adcUpLeftAngle;
        aVal.angle[1] = adcDnLeftAngle;
        aVal.angle[2] = adcUpRightAngle;
        aVal.angle[3] = adcDnRightAngle;
        
        rt_thread_delay(1);
        machine->machineProcess(); 
    }
}

static int ros_task_init(void)
{
    rt_thread_t ros_thread = rt_thread_create("ros_thread", ros_task, RT_NULL, 1024, 11, 5);
    if (ros_thread != RT_NULL)
    {
        rt_thread_startup(ros_thread);
        return 0;
    }
    
    return 1;
}
INIT_APP_EXPORT(ros_task_init);

// ��������
static int ros_machine_reset(void)
{
    machine->reset();

    rt_kprintf("ros_machine_reset cmd was executed\n");
    
    return 0;
}
MSH_CMD_EXPORT(ros_machine_reset, ros_machine_reset cmd);

static int ros_machine_enter(void)
{
    machine->enter();

    rt_kprintf("ros_machine_enter cmd was executed\n");
    
    return 0;
}
MSH_CMD_EXPORT(ros_machine_enter, ros_machine_enter cmd);

static int ros_machine_exit(void)
{
    machine->exit();

    rt_kprintf("ros_machine_exit cmd was executed\n");
    
    return 0;
}
MSH_CMD_EXPORT(ros_machine_exit, ros_machine_exit cmd);
    
static int ros_machine_step(void)
{
    machine->step();
    return 0;
}
MSH_CMD_EXPORT(ros_machine_step, ros_machine_step cmd);

static int ros_machine_run(void)
{
    machine->run();

    rt_kprintf("ros_machine_run cmd was executed\n");
    
    return 0;
}
MSH_CMD_EXPORT(ros_machine_run, ros_machine_run cmd);

static int ros_machine_stop(void)
{
    machine->stop();

    rt_kprintf("ros log:ros_machine_stop cmd was executed\n");
    
    return 0;
}
MSH_CMD_EXPORT(ros_machine_stop, ros_machine_stop cmd);

static int ros_machine_stopLater(void)
{
    machine->stopLater();

    rt_kprintf("ros log:stopLater cmd was executed\n");
    
    return 0;
}
MSH_CMD_EXPORT(ros_machine_stopLater, ros_machine_stopLater cmd);

static int ros_machine_recover(void)
{
    machine->recover();

    rt_kprintf("ros_machine_recover cmd was executed\n");
    
    return 0;
}
MSH_CMD_EXPORT(ros_machine_recover, ros_machine_recover cmd);

static int ros_machine_suspend(void)
{
    machine->suspend();

    rt_kprintf("ros_machine_suspend cmd was executed\n");
    
    return 0;
}
MSH_CMD_EXPORT(ros_machine_suspend, ros_machine_suspend cmd);

// �Ƕȼ�����Ժ���
static int ros_mem_setZero(void)
{
    aMem->setZero(aVal);
    return 0;
}
MSH_CMD_EXPORT(ros_mem_setZero, ros_mem_setZero);

static int ros_mem_getZero(void)
{
    calVal = aMem->getZero();
    return 0;
}
MSH_CMD_EXPORT(ros_mem_getZero, ros_mem_getZero);

static int ros_mem_read(void)
{
    conVal = aMem->getAngle(aVal);
    return 0;
}
MSH_CMD_EXPORT(ros_mem_read, ros_mem_read);

// �ǶȲ��Ժ���
static int ros_sensor_getRead(int argc, char **argv)
{
    uint8_t role = atoi(argv[1]);
    float read;
    switch(role)
    {
        case 1:
            read = S_leftup->read();
            break;
        case 2:
            read = S_leftdn->read();
            break;
        case 3:
            read = S_rightup->read();
            break;
        case 4:
            read = S_rightdn->read();
            break;
        default:
            break;
    }
    
    rt_kprintf("ros log:ros_sensor_getRead, role:%d, angle:%f \n", role, read);
    
    return 0;
}
MSH_CMD_EXPORT(ros_sensor_getRead, ros_sensor_getRead role);

static int ros_sensor_getErr(int argc, char **argv)
{
    uint8_t role = atoi(argv[1]);
    int8_t err;
    switch(role)
    {
        case 1:
            err = S_leftup->getErr();
            break;
        case 2:
            err = S_leftdn->getErr();
            break;
        case 3:
            err = S_rightup->getErr();
            break;
        case 4:
            err = S_rightdn->getErr();
            break;
        default:
            break;
    }
    
    rt_kprintf("ros log:ros_sensor_getErr was executed, role:%d, err is %d\n", role, err);
    
    return 0;
}
MSH_CMD_EXPORT(ros_sensor_getErr, ros_sensor_getErr role);


// �������Ժ���
static int ros_drive_setSpeedALL(int argc, char **argv)
{
    int8_t speed = atoi(argv[1]);
    
    L_leftup->writeSpeedPer(speed);
    L_leftdn->writeSpeedPer(speed);
    L_rightup->writeSpeedPer(speed);
    L_rgihtdn->writeSpeedPer(speed);
    
    rt_kprintf("ros log:ros_dis_enter was executed speed:%d\n", speed);
    
    return 0;
}
MSH_CMD_EXPORT(ros_drive_setSpeedALL, ros_drive_setSpeedALL speed);

static int ros_drive_setSpeed(int argc, char **argv)
{
    uint8_t role = atoi(argv[1]);
    int8_t speed = atoi(argv[2]);
    
    switch(role)
    {
        case 1:
            L_leftup->writeSpeedPer(speed);
            break;
        case 2:
            L_leftdn->writeSpeedPer(speed);
            break;
        case 3:
            L_rightup->writeSpeedPer(speed);
            break;
        case 4:
            L_rgihtdn->writeSpeedPer(speed);
            break;
        default:
            break;
    }
    
    rt_kprintf("ros log:ros_dis_enter was executed, role:%d, speed:%d\n", role, speed);
    
    return 0;
}
MSH_CMD_EXPORT(ros_drive_setSpeed, ros_drive_setSpeed role | speed);

static int ros_drive_closeAll(void)
{
    L_leftup->close();
    L_leftdn->close();
    L_rightup->close();
    L_rgihtdn->close();
    rt_kprintf("ros log:ros_drive_closeAll was executed");
    
    return 0;
}
MSH_CMD_EXPORT(ros_drive_closeAll, ros_drive_closeAll role);

static int ros_drive_close(int argc, char **argv)
{
    uint8_t role = atoi(argv[1]);
    
    switch(role)
    {
        case 1:
            L_leftup->close();
            break;
        case 2:
            L_leftdn->close();
            break;
        case 3:
            L_rightup->close();
            break;
        case 4:
            L_rgihtdn->close();
            break;
        default:
            break;
    }
    
    rt_kprintf("ros log:ros_drive_close was executed, role:%d\n", role);
    
    return 0;
}
MSH_CMD_EXPORT(ros_drive_close, ros_drive_close role);

static int ros_drive_getErr(int argc, char **argv)
{
    uint8_t role = atoi(argv[1]);
    int8_t err;
    switch(role)
    {
        case 1:
            err = L_leftup->getErr();
            break;
        case 2:
            err = L_leftdn->getErr();
            break;
        case 3:
            err = L_rightup->getErr();
            break;
        case 4:
            err = L_rgihtdn->getErr();
            break;
        default:
            break;
    }
    
    rt_kprintf("ros log:ros_drive_getErr was executed, role:%d, err is %d\n", role, err);
    
    return 0;
}
MSH_CMD_EXPORT(ros_drive_getErr, ros_drive_getErr role);


// ���������Ժ���
static int ros_dis_enter(void)
{
    Tdispatch->enter();

    rt_kprintf("ros log:ros_dis_enter was executed\n");
    
    return 0;
}
MSH_CMD_EXPORT(ros_dis_enter, ros_dis_enter cmd);

static int ros_dis_exit(void)
{
    Tdispatch->exit();

    rt_kprintf("ros log:ros_dis_exit was executed\n");
    
    return 0;
}
MSH_CMD_EXPORT(ros_dis_exit, ros_dis_exit cmd);

static int ros_dis_isEnd(void)
{
    rt_kprintf("ros log: action is %d\n", Tdispatch->isActionEnd());
    
    return 0;
}
MSH_CMD_EXPORT(ros_dis_isEnd, ros_dis_isEnd cmd);

static int ros_dis_toNextAction(void)
{
    Tdispatch->toNextAction();

    rt_kprintf("ros log:ros_dis_toNextAction was executed\n");
    
    return 0;
}
MSH_CMD_EXPORT(ros_dis_toNextAction, ros_dis_toNextAction cmd);

static int ros_dis_toNextFrame(void)
{
    int8_t isOk = Tdispatch->toNextFrame();
    rt_kprintf("ros log:ros_dis_toNextFrame was executed : %d\n", isOk);
    
    return 0;
}
MSH_CMD_EXPORT(ros_dis_toNextFrame, ros_dis_toNextFrame cmd);




