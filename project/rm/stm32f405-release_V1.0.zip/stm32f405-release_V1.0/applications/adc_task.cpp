#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>

#define NADC1        "adc1"
#define NADC2        "adc2"
#define NADC3        "adc3"

#define ANGLE_AVERAGE_SIZE      4
#define ANGLE_AVERAGE_SIZE_MOVE 2

#define ANGLE_LEFT_UP_DIR     -1
#define ANGLE_RIGHT_UP_DIR    1
#define ANGLE_LEFT_DN_DIR     1
#define ANGLE_RIGHT_DN_DIR    -1

static uint32_t adc_ch0[ANGLE_AVERAGE_SIZE];                              //ͨ��0�ĵ�ѹֵ
static uint32_t adc_ch1[ANGLE_AVERAGE_SIZE];                              //ͨ��1�ĵ�ѹֵ
static uint32_t adc_ch2[ANGLE_AVERAGE_SIZE];                              //ͨ��2�ĵ�ѹֵ
static uint32_t adc_ch3[ANGLE_AVERAGE_SIZE];                              //ͨ��3�ĵ�ѹֵ
//static uint32_t adc_ch4[ANGLE_AVERAGE_SIZE];                              //ͨ��4�ĵ�ѹֵ
//static uint32_t adc_ch5[ANGLE_AVERAGE_SIZE];                              //ͨ��5�ĵ�ѹֵ
static uint32_t adc_temp[ANGLE_AVERAGE_SIZE];                             //ͨ���¶ȵĵ�ѹֵ
static uint32_t adc_vBat[ANGLE_AVERAGE_SIZE];                             //ͨ��ĸ�ߵ�ѹֵ

rt_adc_device_t adc1_dev;
rt_adc_device_t adc2_dev;
rt_adc_device_t adc3_dev;

float adcUpLeftAngle;
float adcUpRightAngle;
float adcDnLeftAngle;
float adcDnRightAngle;
float adcTemple;
float adcVBat;

float get_temple(float adVal)
{
    float temp = adVal * 3.3f / 4096;
    temp = (temp - 0.76f)*1000/2.5f + 25;
    
    return temp;
}

float get_vBat(float adVal)
{
    float vBat = adVal * 3.3f / 4096;
    vBat = vBat * 11;

    return vBat;
}

float get_angle(float adVal)
{
    float angle;
    angle = (adVal * 360) / 4096 - 180;
    
    return angle;
}

static void angle_average_cal(float *AD, uint32_t *ADArray)
{
    int32_t angleADSum = 0;
    
    for(uint8_t i = 0; i < ANGLE_AVERAGE_SIZE; i++)
    {
        angleADSum += ADArray[i];
    }
    angleADSum = angleADSum >> ANGLE_AVERAGE_SIZE_MOVE;
    
    /* һ���ͺ� */
    //*AD = ( *AD * 3 + angleADSum) >> 2;
    *AD = (float)angleADSum; 
}

void adc_getAdVal(void)
{
    static uint8_t adAverageCount = 0;
    
    adc_ch0[adAverageCount] = rt_adc_read(adc3_dev, 0);
    adc_ch1[adAverageCount] = rt_adc_read(adc3_dev, 1);
    adc_ch2[adAverageCount] = rt_adc_read(adc3_dev, 2);
    adc_ch3[adAverageCount] = rt_adc_read(adc3_dev, 3);
    
    //adc_ch4[adAverageCount] = rt_adc_read(adc2_dev, 4);
    //adc_ch5[adAverageCount] = rt_adc_read(adc2_dev, 5);
    
    adc_temp[adAverageCount] = rt_adc_read(adc1_dev, 16);
    adc_vBat[adAverageCount] = rt_adc_read(adc1_dev, 6);
    
    adAverageCount++;
    if(adAverageCount >= ANGLE_AVERAGE_SIZE)
    {
        adAverageCount = 0;
        
        // ����Ƕȵ�ѹƽ��ֵ
        angle_average_cal(&adcUpLeftAngle,  adc_ch3);
        angle_average_cal(&adcUpRightAngle, adc_ch1);
        angle_average_cal(&adcDnLeftAngle,  adc_ch2);
        angle_average_cal(&adcDnRightAngle, adc_ch0); 
        
        // NOT USED
        //angle_average_cal(&adcDnLeftAngle,  adc_ch2);
        //angle_average_cal(&adcDnRIghtAngle, adc_ch3);  
        
        angle_average_cal(&adcTemple, adc_temp); 
        angle_average_cal(&adcVBat, adc_vBat); 
        
        // ����ʵ��
        adcUpLeftAngle = get_angle(adcUpLeftAngle);
        adcUpRightAngle = get_angle(adcUpRightAngle);
        adcDnLeftAngle = get_angle(adcDnLeftAngle);
        adcDnRightAngle = get_angle(adcDnRightAngle);
        adcTemple = get_temple(adcTemple);
        adcVBat = get_vBat(adcVBat);
        
        // �����Ƕȷ���
        adcUpLeftAngle = adcUpLeftAngle * ANGLE_LEFT_UP_DIR;
        adcUpRightAngle = adcUpRightAngle * ANGLE_RIGHT_UP_DIR;
        adcDnLeftAngle = adcDnLeftAngle * ANGLE_LEFT_DN_DIR;
        adcDnRightAngle = adcDnRightAngle * ANGLE_RIGHT_DN_DIR;
    }
}

static void adc_task(void* parameter)
{
    
    
    adc1_dev = (rt_adc_device_t)rt_device_find(NADC1);
    adc2_dev = (rt_adc_device_t)rt_device_find(NADC2);
    adc3_dev = (rt_adc_device_t)rt_device_find(NADC3);
    
    rt_adc_enable(adc1_dev, 16);        // �ڲ��¶�
    rt_adc_enable(adc1_dev, 6);         // vbat
    rt_adc_enable(adc2_dev, 5);         // IN5
    rt_adc_enable(adc2_dev, 4);         // IN4
    rt_adc_enable(adc3_dev, 3);         // IN3
    rt_adc_enable(adc3_dev, 2);         // IN2
    rt_adc_enable(adc3_dev, 1);         // IN1
    rt_adc_enable(adc3_dev, 0);         // IN0
    
    while(1)
    {
        rt_thread_delay(1);  
        adc_getAdVal();       
    }
}

static int adc_task_init(void)
{
    rt_thread_t adc_thread = rt_thread_create("adcTask", adc_task, RT_NULL, 512, 6, 5);
    if (adc_thread != RT_NULL)
    {
        rt_thread_startup(adc_thread);
        return 0;
    }
    
    return 1;
}
INIT_APP_EXPORT(adc_task_init);
