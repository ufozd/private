#include <rtthread.h>
#include "motor_modbusCmd.h"
#include <stdlib.h>
#include <rMB_Master_Drv.h>
#include <board.h>

#define MODBUS_GATA_PIN GET_PIN(A, 8)
rt_device_t serial1;
rMB_master_type mbMaster;
uint8_t masterState;


typedef struct 
{   
    uint8_t func;
    uint16_t regAddr;
    uint16_t regSize;
    uint8_t *pData;
}SendData_type;

SendData_type testCmd = 
{
    .func = RMB_WRITE_COMPLEX_KEEPREG,
    .regAddr = 0,
    .regSize = 100,
    .pData = NULL,
};
rt_event_t mdEvent;

static void modbus_open_gate(void)
{
    rt_pin_write(MODBUS_GATA_PIN, 1);
    
    for(uint8_t i = 0; i < 10; i++)
    {
        __nop();
    }
}

static void modbus_close_gate(void)
{
    rt_pin_write(MODBUS_GATA_PIN, 0);
}

static uint8_t modbus_slave_send(uint8_t *pData, uint16_t len)
{
    modbus_open_gate();
    rt_device_write(serial1, 0, pData, len);
    rMB_master_send_complete_api(&mbMaster);
    modbus_close_gate();
    return 0;
}

static rt_err_t uart_input(rt_device_t dev, rt_size_t size)
{
    //dev:�������豸����� size�����������ݳ���
    uint8_t data;
    for(rt_size_t i = 0; i < size; i++)
    {
        rt_device_read(serial1, i, &data, 1);
        rMB_master_recive_api(&mbMaster, data);
    }
    
    return RT_EOK;
}

static void modbus_com(void *parameter)
{
    rt_pin_mode(MODBUS_GATA_PIN, PIN_MODE_OUTPUT);
    modbus_close_gate();

    serial1 = rt_device_find("uart1");
    rt_device_open(serial1, RT_DEVICE_OFLAG_RDWR | RT_DEVICE_FLAG_INT_RX);
    rt_device_set_rx_indicate(serial1, uart_input);
    rMB_master_init(&mbMaster, modbus_slave_send, MASTERID, 25, 2);
    
    mdEvent = rt_event_create("mdOK", RT_IPC_FLAG_FIFO);
    while (1)
    {
        rt_thread_mdelay(1);
        masterState = rMB_master_1ms_drv(&mbMaster);
        if(masterState == rMB_MASTER_READY)
        {
            rt_event_send(mdEvent, mdEVENT_OK);
        }
        else if(masterState == rMB_MASTER_NO_RESPOND)
        {
            rt_event_send(mdEvent, mdEVENT_FAIL);
        }
    }
}

static int modbus_init(void)
{
    rt_thread_t tid1 = RT_NULL;
    tid1 = rt_thread_create("mdCom", modbus_com, RT_NULL, 512, 9, 5);
    
    if (tid1 == RT_NULL)
    {    
        return 0;
    }

    rt_thread_startup(tid1);
    return 1;
}
INIT_APP_EXPORT(modbus_init);

/* ʹ��modbus �����ٶ����� */
int8_t motor_setSpeedPer_MB(int8_t Per, uint8_t role)
{
    int16_t data[2] = {1, 0};
    switch(role)
    {
        case 1:
            Per = Per * MOTOR_LEFT_UP_DIR;
            break;
        case 2:
            Per = Per * MOTOR_LEFT_DN_DIR;
            break;
        case 3: 
            Per = Per * MOTOR_RIGHT_UP_DIR;
            break;
        case 4:
            Per = Per * MOTOR_RIGHT_DN_DIR;
            break;
        default:
            break;
    }
    
    data[1] = Per * 10;           // ��λ����1/1000
    testCmd.func = RMB_WRITE_COMPLEX_KEEPREG;
    testCmd.regAddr = 20;
    testCmd.regSize = 2;
    testCmd.pData = (uint8_t *)&data;
    
    return rMB_master_send(&mbMaster, role, testCmd.func, testCmd.regAddr, testCmd.regSize, testCmd.pData);
}

/* ʹ��modbus ����ͣ������ */
int8_t motor_close_MB(uint8_t role)
{
    int16_t data[1] = {2};
   
    testCmd.func = RMB_WRITE_COMPLEX_KEEPREG;
    testCmd.regAddr = 20;
    testCmd.regSize = 2;
    testCmd.pData = (uint8_t *)&data;
    
    return rMB_master_send(&mbMaster, role, testCmd.func, testCmd.regAddr, testCmd.regSize, testCmd.pData);
}

/* ʹ��modbus ����ĸ�ߵ�ѹ */
int8_t motor_get_vbus_MB(uint8_t role)
{
    testCmd.func = RMB_READ_KEEPREG;
    testCmd.regAddr = 10;
    testCmd.regSize = 1;
    testCmd.pData = RT_NULL;
    
    return rMB_master_send(&mbMaster, role, testCmd.func, testCmd.regAddr, testCmd.regSize, testCmd.pData);
}

/* ʹ��modbus ���ҹ���״̬ */
int8_t motor_get_err_MB(uint8_t role)
{
    testCmd.func = RMB_READ_KEEPREG;
    testCmd.regAddr = 11;
    testCmd.regSize = 1;
    testCmd.pData = RT_NULL;
    
    return rMB_master_send(&mbMaster, role, testCmd.func, testCmd.regAddr, testCmd.regSize, testCmd.pData);
}

/* ʹ��modbus ���ҹ���״̬ */
int8_t motor_get_state_MB(uint8_t role)
{
    testCmd.func = RMB_READ_KEEPREG;
    testCmd.regAddr = 12;
    testCmd.regSize = 1;
    testCmd.pData = RT_NULL;
    
    return rMB_master_send(&mbMaster, role, testCmd.func, testCmd.regAddr, testCmd.regSize, testCmd.pData);
}

/* ʹ��modbus ��������״̬ */
int8_t motor_get_stateAll_MB(uint8_t role)
{
    testCmd.func = RMB_READ_KEEPREG;
    testCmd.regAddr = 10;
    testCmd.regSize = 3;
    testCmd.pData = RT_NULL;
    
    return rMB_master_send(&mbMaster, role, testCmd.func, testCmd.regAddr, testCmd.regSize, testCmd.pData);
}
