/*
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2018-11-06     SummerGift   first version
 * 2018-11-19     flybreak     add stm32f429-fire-challenger bsp
 */

#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <stdlib.h>
#include "at24cxx.h"
#include "ros_machine.hpp"

at24cxx_device_t at24c02;
extern ros_machine *machine;
#define LED_PIN GET_PIN(A, 15)

angleVal val = {0};
uint8_t write_flag = 0;

extern float adcUpLeftAngle;
extern float adcUpRightAngle;
extern float adcDnLeftAngle;
extern float adcDnRightAngle;

int main(void)
{
    static uint8_t level = 0;
    rt_pin_mode(LED_PIN, PIN_MODE_OUTPUT);
  
    rt_thread_delay(10);
    at24c02 = at24cxx_init("i2c1", 3);
    rt_thread_delay(10);
    at24cxx_page_read(at24c02, 0, (uint8_t *)&val, sizeof(val));
    machine->setZeroFromCalVal(val);
    while(1)
    {
        level = !level;
        rt_pin_write(LED_PIN, level);
        if(write_flag)
        {
            write_flag = 0;
            val = machine->getZero();
            at24cxx_page_write(at24c02, 0, (uint8_t *)&val, sizeof(val));
        }
        
        rt_thread_delay(500);
    }
    return RT_EOK;
}

static int angle_setZero(void)
{
    machine->setZero();
    write_flag = 1;
    return 0;
}
MSH_CMD_EXPORT(angle_setZero, angle_setZero cmd);


static int ECHO(int argc, char **argv)
{
    rt_kprintf("ECHO is get %s\r\n", argv[1]);
    
    return 0;
}
MSH_CMD_EXPORT(ECHO, ECHO str);
