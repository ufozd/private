#include "motor_modbusPoll.h"
#include "motor_modbusCmd.h"
#include <rtthread.h>

extern rt_event_t mdEvent;
extern uint8_t writeFlag;
extern uint16_t masterreg[100];

typedef struct
{
    uint8_t motor1StartFlag;
    uint8_t motor2StartFlag;
    uint8_t motor3StartFlag;
    uint8_t motor4StartFlag;
    
    uint8_t motor1StopFlag;
    uint8_t motor2StopFlag;
    uint8_t motor3StopFlag;
    uint8_t motor4StopFlag;
    
    uint8_t motor1StateAllFlag;
    uint8_t motor2StateAllFlag;
    uint8_t motor3StateAllFlag;
    uint8_t motor4StateAllFlag;
    
    int8_t motorPer[5];
    uint8_t *proSendPoint;
    uint8_t role;
    uint8_t roleFailCnt;
    
    uint8_t modbusErr[5];
    uint16_t vbus[5];
    uint16_t err[5];
    uint16_t workState[5];
    
    
}rec_type;
rec_type rec;

static uint8_t motorStopFlagDeal(uint8_t *flag, uint8_t role)
{
    if(*flag && rec.modbusErr[role] != 1)
    {
        rec.role = role;
        rec.proSendPoint = flag;
        motor_close_MB(role);
        
        return 1;
    }
    return 0;
}

static uint8_t motorStartFlagDeal(uint8_t *flag, uint8_t role)
{
    if(*flag && rec.modbusErr[role] != 1)
    {
        rec.role = role;
        rec.proSendPoint = flag;
        motor_setSpeedPer_MB(rec.motorPer[role], role);
        
        return 1;
    }
    return 0;
}

static uint8_t motorStateAllFlagDeal(uint8_t *flag, uint8_t role)
{
    if(*flag && rec.modbusErr[role] != 1)
    {
        rec.role = role;
        rec.proSendPoint = flag;
        motor_get_stateAll_MB(role);
        
        return 1;
    }
    return 0;
}

static void modbus_poll(void)
{
    static rt_uint32_t e;
    uint8_t state = 0;
    if(rt_event_recv(mdEvent, mdEVENT_OK, RT_EVENT_FLAG_AND | RT_EVENT_FLAG_CLEAR, 0, &e) == RT_EOK)
    {
        state = 1;  // �ϴη��ͳɹ�
        rec.roleFailCnt = 0;
        rec.err[rec.role] = 0;
        
        if(rec.proSendPoint != RT_NULL)
        {
            if(*(rec.proSendPoint) == 0)
            {
                rec.proSendPoint = RT_NULL;
            }
            else
            {
                *(rec.proSendPoint) = 0; 
            }
        }
    }
    else if(rt_event_recv(mdEvent, mdEVENT_FAIL, RT_EVENT_FLAG_AND | RT_EVENT_FLAG_CLEAR, 0, &e) == RT_EOK)
    {
        rec.roleFailCnt++;
        if(rec.roleFailCnt >= 3)
        {
            rec.roleFailCnt = 0;
            rec.modbusErr[rec.role] = 1;
            rec.err[rec.role] = MOTOR_MODBUS_ERR;
            
            *(rec.proSendPoint) = 0; 
        }
        state = 2;  // ���Է�����
    }
    else
    {
        state = 0;
    }  
    
    if(writeFlag)
    {
        writeFlag = 0;      // ����״̬����
        
        rec.vbus[rec.role] = masterreg[10];
        rec.err[rec.role] = masterreg[11];
        rec.workState[rec.role] = masterreg[12];
    }
    
    if(state)
    {
        if(motorStopFlagDeal(&rec.motor1StopFlag, 1))
        {
            return;
        }
        
        if(motorStopFlagDeal(&rec.motor2StopFlag, 2))
        {
            return;
        }
        
        if(motorStopFlagDeal(&rec.motor3StopFlag, 3))
        {
            return;
        }
        
        if(motorStopFlagDeal(&rec.motor4StopFlag, 4))
        {
            return;
        }
        
        if(motorStartFlagDeal(&rec.motor1StartFlag, 1))
        {
            return;
        }
        
        if(motorStartFlagDeal(&rec.motor2StartFlag, 2))
        {
            return;
        }
        
        if(motorStartFlagDeal(&rec.motor3StartFlag, 3))
        {
            return;
        }
        
        if(motorStartFlagDeal(&rec.motor4StartFlag, 4))
        {
            return;
        }
        
        if(motorStateAllFlagDeal(&rec.motor1StateAllFlag, 1))
        {
            return;
        }
        
        if(motorStateAllFlagDeal(&rec.motor2StateAllFlag, 2))
        {
            return;
        }
        
        if(motorStateAllFlagDeal(&rec.motor3StateAllFlag, 3))
        {
            return;
        }
        
        if(motorStateAllFlagDeal(&rec.motor4StateAllFlag, 4))
        {
            return;
        }
    }
}

static void modbus_deal(void *parameter)
{
    static uint16_t delaCnt = 0;
    rt_thread_mdelay(100);
    
    while (1)
    {
        rt_thread_mdelay(5);
        
        modbus_poll();
        
        if(++delaCnt >= 200)  // 1s ��ѯһ�β���
        {
            delaCnt = 0;
            rec.motor1StateAllFlag = 1;
            rec.modbusErr[1] = 0;
            rec.motor2StateAllFlag = 1;
            rec.modbusErr[2] = 0;
            rec.motor3StateAllFlag = 1;
            rec.modbusErr[3] = 0;
            rec.motor4StateAllFlag = 1;
            rec.modbusErr[4] = 0;
        }
        
    }
}

static int modbus_poll_init(void)
{
    rt_thread_t tid2 = RT_NULL;
    tid2 = rt_thread_create("mdDeal", modbus_deal, RT_NULL, 512, 8, 5);

    if (tid2 == RT_NULL)
    {    
        return 0;
    }
    
    rt_thread_startup(tid2);
    rec.proSendPoint = RT_NULL;
    return 1;
}
INIT_APP_EXPORT(modbus_poll_init);


/* ��ʼ��һ����� */
int8_t motor_set_init(uint8_t role)
{
    return 0;
}

int8_t motor_getErr(uint8_t role)
{
    if(rec.err[role] != MOTOR_NOERR)
    {
        return 1;
    }
    return 0;
}

int8_t motor_setAngle(int16_t angle, uint8_t role)
{
    return 0;
}

int8_t motot_setSpeedPer(int8_t Per, uint8_t role)
{
    switch(role)
    {
        case 1:
            rec.motorPer[role] = Per;
            rec.motor1StartFlag = 1;
            break;
        case 2:
            rec.motorPer[role] = Per;
            rec.motor2StartFlag = 1;
            break;
        case 3:
            rec.motorPer[role] = Per;
            rec.motor3StartFlag = 1;
            break;
        case 4:
            rec.motorPer[role] = Per;
            rec.motor4StartFlag = 1;
            break;
        default:
            break;
    }
    
    return 0;
}

int8_t motor_close(uint8_t role)
{
    switch(role)
    {
        case 1:
            rec.motor1StopFlag = 1;
            rec.motor1StartFlag = 0;       // ��Ϊ��ѯ��������ܻ����start��δ����,����stop�������ͣ��������stop��Ч��
            break;
        case 2:
            rec.motor2StopFlag = 1;
            rec.motor2StartFlag = 0;
            break;
        case 3:
            rec.motor3StopFlag = 1;
            rec.motor3StartFlag = 0;
            break;
        case 4:
            rec.motor4StopFlag = 1;
            rec.motor4StartFlag = 0;
            break;
        default:
            break;
    }
    
    return 0;
}


// ���������Ժ���
static int modebus_start_all(void)
{
    motot_setSpeedPer(50, 1);
    motot_setSpeedPer(50, 2);
    motot_setSpeedPer(50, 3);
    motot_setSpeedPer(50, 4);
    
    return 0;
}
MSH_CMD_EXPORT(modebus_start_all, modebus_start);

// ���������Ժ���
static int modebus_stop_all(void)
{
    motor_close(1);
    motor_close(2);
    motor_close(3);
    motor_close(4);
    
    return 0;
}
MSH_CMD_EXPORT(modebus_stop_all, modebus_stop);


static int modebus_start(void)
{
    motot_setSpeedPer(50, 4);
    //motot_setSpeedPer(40, 2);
    //motot_setSpeedPer(40, 3);
    return 0;
}
MSH_CMD_EXPORT(modebus_start, modebus_start);

static int modebus_stop(void)
{
    motor_close(4);
    //motor_close(2);
    //motor_close(3);
    return 0;
}
MSH_CMD_EXPORT(modebus_stop, modebus_stop);

static int modebus_call(void)
{
    rec.motor1StateAllFlag = 1;
    return 0;
}
MSH_CMD_EXPORT(modebus_call, modebus_call);

