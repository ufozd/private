#ifndef __WIRELESS2_4G_H__
#define __WIRELESS2_4G_H__

#include <rtthread.h>

#define MES_LENGTH 32
#define MES_SIZE   5

typedef struct
{
    uint8_t msg_pool[MES_SIZE][MES_LENGTH];
    struct rt_messagequeue mq;
    
}wireLess_type;

void wireless_init(void);

#endif
