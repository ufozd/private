#include "bsp_time.h"
#include "main.h"
#include "tim.h"

// 2021/2/22 �ǵ�hall������Ҫ�������������߻�����޷����ߵ����

bspMotor_type bspMotor;         // ֱ�Ӷ���һ��������Ƶ�bsp������

/* ����� */
typedef enum
{ 
    C_PLUS__A_SUB = 1,
    A_PLUS__B_SUB = 2,
    C_PLUS__B_SUB = 3,
    B_PLUS__C_SUB = 4,
    B_PLUS__A_SUB = 5,
    A_PLUS__C_SUB = 6,
    ALL_STATE = 7,
}Hall_state_type;

void HALL_timer_init(void);
void HALL_timer_start(void);
void HALL_timer_stop(void);
uint32_t HALL_get_state(void);

void BLCD_timer_init(void);
void BLCD_timer_commutation(uint32_t step, uint16_t Duty);
void BLCD_timer_pwm_stop(void);

/* bsp���Ƶ���ĳ�ʼ�� */
bspMotor_type* bspMotor_init(void)
{
    HALL_timer_init();
    BLCD_timer_init();
    
    bspMotor.startDuty = DEFAULTDUTY;
    bspMotor.dir = 1;
    bspMotor.maxDuty = MAX_DUTY;
    bspMotor.runDuty = 0;
    
    return &bspMotor;
}

/* bsp���Ƶ�������� */
void bspMotor_start(void)
{
    HALL_timer_start();
    bspMotor.runDuty = bspMotor.startDuty;
}

/* bsp���Ƶ����ֹͣ */
void bspMotor_stop(void)
{
    HALL_timer_stop();
    BLCD_timer_pwm_stop();
    bspMotor.runDuty = 0;
}

/* bsp������������ռ�ձ� */
void bspMotor_setStartDuty(uint16_t duty)
{
    if(duty > bspMotor.maxDuty)
    {
        duty = bspMotor.maxDuty;
    }
    bspMotor.startDuty = duty;
}

/* bsp������������ռ�ձ� */
void bspMotor_setRunDuty(uint16_t duty)
{
    if(duty > bspMotor.maxDuty)
    {
        duty = bspMotor.maxDuty;
    }
    bspMotor.runDuty = duty;
}

/* bsp�����������ռ�ձ� */
void bspMotor_setMaxDuty(uint16_t duty)
{
    if(duty > MAX_DUTY)
    {
        duty = MAX_DUTY;
    }
    bspMotor.maxDuty = duty;
    
    if(bspMotor.startDuty > bspMotor.maxDuty)
    {
        bspMotor.startDuty = bspMotor.maxDuty;
    }
    
    if(bspMotor.runDuty > bspMotor.maxDuty)
    {
        bspMotor.runDuty = bspMotor.maxDuty;
    }
}

/* bsp�������÷���, �м�Ҫ��ͣ�º����л�����*/
void bspMotor_setDir(int8_t dir)
{
    bspMotor.dir = dir;
}

/* bsp��������hall�Ļص�����, ��Ҫ���ڲ��ٵ� */
void bspMotor_setHallcallback(hall_callback call)
{
    bspMotor.callback = call;
}

/*************************************************************************************************************���������� */
/* Hall��ʱ���ĳ�ʼ�� */
void HALL_timer_init(void)
{
    TIM_HallSensor_InitTypeDef sHallSensorConfig;
    
    sHallSensorConfig.IC1Prescaler = TIM_ICPSC_DIV1;
    sHallSensorConfig.IC1Polarity = TIM_ICPOLARITY_BOTHEDGE;
    sHallSensorConfig.IC1Filter = 10;
    sHallSensorConfig.Commutation_Delay = 0;
    
    HAL_TIMEx_HallSensor_Init(&HALL_TIMER, &sHallSensorConfig);
}

/* Hall����״̬��ȡ */
uint32_t HALL_get_state(void)
{
    __IO static uint32_t State ;
    State  = 0;
    if( HAL_GPIO_ReadPin(HALL_CH1_GPIO_Port,HALL_CH1_Pin) != GPIO_PIN_RESET)
    {
        State |= (0x01U << 0);
    }
    if(HAL_GPIO_ReadPin(HALL_CH2_GPIO_Port,HALL_CH2_Pin) != GPIO_PIN_RESET)
    {
        State |= (0x01U << 1);
    }
    if(HAL_GPIO_ReadPin(HALL_CH3_GPIO_Port,HALL_CH3_Pin) != GPIO_PIN_RESET)
    {
        State |= (0x01U << 2);
    }
    return State;
}

/* ����Hall��ʱ�� */
void HALL_timer_start(void)
{
    bspMotor.err = 0;
    __HAL_TIM_ENABLE_IT(&HALL_TIMER, TIM_IT_TRIGGER);    
    BLCD_timer_commutation(HALL_get_state(), (uint32_t)PWM_VAL * bspMotor.startDuty / 1000);         // ״̬Ԥ�ȴ���
    HAL_TIMEx_HallSensor_Start(&HALL_TIMER); 
    
}

/* ֱ���趨���� */
void bspMotor_setTorque(uint16_t duty)
{
    BLCD_timer_commutation(HALL_get_state(), (uint32_t)PWM_VAL * bspMotor.startDuty / 1000);
}

/* �ر�Hall��ʱ�� */
void HALL_timer_stop(void)
{
    __HAL_TIM_DISABLE_IT(&HALL_TIMER, TIM_IT_TRIGGER);  // �����ж� ���жϻص������л���
    HAL_TIMEx_HallSensor_Stop(&HALL_TIMER); 
}

/*************************************************************************************************************��ˢ��� */
/* ��ʼ������BLCD�Ķ�ʱ�� */
void BLCD_timer_init(void)
{
    HAL_TIMEx_ConfigCommutationEvent(&BLDC_TIMER, TIM_TS_NONE, TIM_COMMUTATION_SOFTWARE);
    BLCD_timer_pwm_stop();
    
}

/* ����hall״̬���л�״̬������PWM */
void BLCD_timer_commutation(uint32_t step, uint16_t Duty)
{
    if(bspMotor.dir)
    {
        step = ALL_STATE - step;
    }
    
    switch(step)
    {
        case C_PLUS__A_SUB:  //����״̬ ��001
            HAL_TIM_PWM_Stop(&BLDC_TIMER, TIM_CHANNEL_2);
            HAL_TIMEx_PWMN_Stop(&BLDC_TIMER, TIM_CHANNEL_2);
        
            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_3,Duty);
            HAL_TIMEx_PWMN_Start(&BLDC_TIMER, TIM_CHANNEL_3);

            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_1,PWM_VAL + 1);
            HAL_TIM_PWM_Start(&BLDC_TIMER, TIM_CHANNEL_1);
            break;
        case A_PLUS__B_SUB:   //����״̬ ��010
            HAL_TIM_PWM_Stop(&BLDC_TIMER, TIM_CHANNEL_3);
            HAL_TIMEx_PWMN_Stop(&BLDC_TIMER, TIM_CHANNEL_3);

            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_1,Duty);
            HAL_TIMEx_PWMN_Start(&BLDC_TIMER, TIM_CHANNEL_1);

            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_2,PWM_VAL + 1);
            HAL_TIM_PWM_Start(&BLDC_TIMER, TIM_CHANNEL_2);
            break;
        case C_PLUS__B_SUB:  //����״̬ ��011
            HAL_TIM_PWM_Stop(&BLDC_TIMER, TIM_CHANNEL_1);
            HAL_TIMEx_PWMN_Stop(&BLDC_TIMER, TIM_CHANNEL_1);

            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_3,Duty);
            HAL_TIMEx_PWMN_Start(&BLDC_TIMER, TIM_CHANNEL_3);
        
            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_2,PWM_VAL + 1);
            HAL_TIM_PWM_Start(&BLDC_TIMER, TIM_CHANNEL_2);
            break;
        case B_PLUS__C_SUB:  //����״̬ ��100
            HAL_TIM_PWM_Stop(&BLDC_TIMER, TIM_CHANNEL_1);
            HAL_TIMEx_PWMN_Stop(&BLDC_TIMER, TIM_CHANNEL_1);

            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_2,Duty);
            HAL_TIMEx_PWMN_Start(&BLDC_TIMER, TIM_CHANNEL_2);

            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_3,PWM_VAL + 1);    
            HAL_TIM_PWM_Start(&BLDC_TIMER, TIM_CHANNEL_3);
            break;
        case B_PLUS__A_SUB:   //����״̬ ��101
            HAL_TIM_PWM_Stop(&BLDC_TIMER, TIM_CHANNEL_3);
            HAL_TIMEx_PWMN_Stop(&BLDC_TIMER, TIM_CHANNEL_3);

            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_2,Duty);
            HAL_TIMEx_PWMN_Start(&BLDC_TIMER, TIM_CHANNEL_2);

            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_1,PWM_VAL + 1);
            HAL_TIM_PWM_Start(&BLDC_TIMER, TIM_CHANNEL_1);
            break;
        case A_PLUS__C_SUB:   //����״̬ ��110
            HAL_TIM_PWM_Stop(&BLDC_TIMER, TIM_CHANNEL_2);
            HAL_TIMEx_PWMN_Stop(&BLDC_TIMER, TIM_CHANNEL_2);

            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_1,Duty);
            HAL_TIMEx_PWMN_Start(&BLDC_TIMER, TIM_CHANNEL_1); 

            __HAL_TIM_SET_COMPARE(&BLDC_TIMER,TIM_CHANNEL_3, PWM_VAL + 1);  
            HAL_TIM_PWM_Start(&BLDC_TIMER, TIM_CHANNEL_3);
            break;
        default:
            // �쳣����
            bspMotor.err = 1;
            HALL_timer_stop(); 
            BLCD_timer_pwm_stop();
            break;
    }
    
    HAL_TIM_GenerateEvent(&BLDC_TIMER, TIM_EVENTSOURCE_COM);  // ���� COM�¼������л�
}

/* ֹͣȫ��PWM */
void BLCD_timer_pwm_stop(void)
{
    HAL_TIM_PWM_Stop(&BLDC_TIMER, TIM_CHANNEL_1);
    HAL_TIMEx_PWMN_Stop(&BLDC_TIMER, TIM_CHANNEL_1);
    HAL_TIM_PWM_Stop(&BLDC_TIMER, TIM_CHANNEL_2);
    HAL_TIMEx_PWMN_Stop(&BLDC_TIMER, TIM_CHANNEL_2);
    HAL_TIM_PWM_Stop(&BLDC_TIMER, TIM_CHANNEL_3);
    HAL_TIMEx_PWMN_Stop(&BLDC_TIMER, TIM_CHANNEL_3);
}

/* ��ʱ������ص� */
void HAL_TIM_TriggerCallback(TIM_HandleTypeDef *htim)
{
    uint16_t pwmOut = (uint32_t)PWM_VAL * bspMotor.runDuty / 1000;
    
    /* hall��ʱ�������� */
    if(htim == &HALL_TIMER)
    {
        if(bspMotor.callback != NULL)
        {
            uint32_t hallTime = __HAL_TIM_GET_COMPARE(htim, TIM_CHANNEL_1);
            bspMotor.callback(hallTime);
        }

        BLCD_timer_commutation(HALL_get_state(), pwmOut);
    }
}
