#include "ADCTask.h"
#include "main.h"
#include "cmsis_os.h"
#include "motor_ctrl.h"

static void adcTask_running(void const * argument);
osThreadId adcTask_id;
osThreadDef(adcTask, adcTask_running, osPriorityNormal, 0, 256);

extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;
extern ADC_HandleTypeDef hadc3;
extern TIM_HandleTypeDef htim12;
extern uint16_t slavereg[100];

adcTaskData adcData;

static uint32_t adcGet(ADC_CHANNEL_type channel)
{
    ADC_HandleTypeDef *adcHandle;
    ADC_ChannelConfTypeDef sConfig = {0};
    
    sConfig.Rank = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
    switch(channel)
    {
        case ADC_TEMP_CHANNEL:
            sConfig.Channel = ADC_CHANNEL_16;             // adc1 16
            adcHandle = &hadc1;
            break;
        case ADC_VBUS_CHANNEL:
            sConfig.Channel = ADC_CHANNEL_10;             // adc3 10
            adcHandle = &hadc3;
            break;
        case ADC_IA_CHANNEL:
            sConfig.Channel = ADC_CHANNEL_6;              // adc1 6
            adcHandle = &hadc1;
            break;
        case ADC_IB_CHANNEL:
            sConfig.Channel = ADC_CHANNEL_7;              // adc1 7
            adcHandle = &hadc1;
            break;
        case ADC_IC_CHANNEL:
            sConfig.Channel = ADC_CHANNEL_14;             // adc1 14
            adcHandle = &hadc1;
            break;
        default:
            break;
    }
    
    HAL_ADC_ConfigChannel(adcHandle, &sConfig);
    HAL_ADC_Start(adcHandle);
    HAL_ADC_PollForConversion(adcHandle, 10);
    
    return HAL_ADC_GetValue(adcHandle);
}

float adcGet_vBat(float adVal)
{
    float vBat = adVal * 3.3f / 4096;
    vBat = vBat * 8;

    return vBat;
}

float adcGet_temple(float adVal)
{
    float temp = adVal * 3.3f / 4096;
    temp = (temp - 0.76f)*1000/2.5f + 25;
    
    return temp;
}

float adcGet_current(float adVal)
{
    float current = adVal * 3.3f / 4096;
    current = current - (3.3f / 2);
    if(current < 0)
    {
        current = -current;
    }

    current = current * 33;   // ����ֵ ����Ӧ����10
    return current;
}

float adc_average(int32_t *group, uint16_t size)
{
    int32_t sum = 0;
    for(uint16_t i = 0; i < size; i++)
    {
        sum += group[i];
    }
    
    sum = sum / size;
    
    return (float)sum;
}

void adc_setZero(void)
{
    adcData.ia_zero = adcGet(ADC_IA_CHANNEL) - 4096/2;
    adcData.ib_zero = adcGet(ADC_IB_CHANNEL) - 4096/2;
    adcData.ic_zero = adcGet(ADC_IC_CHANNEL) - 4096/2;
}

void adcTask_init(void)
{
    adcData.sampleCnt = 0;
    adcTask_id = osThreadCreate(osThread(adcTask), NULL);
}

void HAL_time_get_adc(void)
{
    adcData.adcTemp[adcData.sampleCnt] = adcGet(ADC_TEMP_CHANNEL);
    adcData.adcBus[adcData.sampleCnt] = adcGet(ADC_VBUS_CHANNEL);

    adcData.adcia[adcData.currentCnt] = adcGet(ADC_IA_CHANNEL) - adcData.ia_zero;
    adcData.adcib[adcData.currentCnt] = adcGet(ADC_IB_CHANNEL) - adcData.ib_zero;
    adcData.adcic[adcData.currentCnt] = adcGet(ADC_IC_CHANNEL) - adcData.ic_zero;
    
    adcData.sampleCnt++;
    if(adcData.sampleCnt >= ADC_BUFF_SIZE)
    {
        adcData.sampleCnt = 0;
        
        adcData.temple = adcGet_temple(adc_average(adcData.adcTemp, ADC_BUFF_SIZE));
        adcData.vbus = adcGet_vBat(adc_average(adcData.adcBus, ADC_BUFF_SIZE));
    }
    
    adcData.currentCnt++;
    if(adcData.currentCnt >= ADC_CURRENT_SIZE)
    {
        adcData.currentCnt = 0;
        
        adcData.ia = adcGet_current(adc_average(adcData.adcia, ADC_CURRENT_SIZE));
        adcData.ib = adcGet_current(adc_average(adcData.adcia, ADC_CURRENT_SIZE));
        adcData.ic = adcGet_current(adc_average(adcData.adcia, ADC_CURRENT_SIZE));
    }
}

void adcTask_running(void const * argument)
{
    static uint16_t ms = 0;
    osDelay(500);
    adc_setZero();
    HAL_TIM_Base_Start_IT(&htim12);
    while(1)
    {
        osDelay(1);
        
        if(adcData.ia > MOTOR_MAX_CURRENT || adcData.ib > MOTOR_MAX_CURRENT || adcData.ic > MOTOR_MAX_CURRENT)
        {
            motor_stop();
            motor_overCurrent();
        }
        
        if(ms++ >= 500)
        {
            ms = 0;
            HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
        }
        
        slavereg[10] = (uint16_t)adcData.vbus;  // ��ǰĸ�ߵ�ѹ
        
    }
}

