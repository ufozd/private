#include "motor_ctrl.h"
#include "stdlib.h"

// �����и����⣬ �������е�������Ҫ����hall�жϵģ����һֱ����ת�Ļ�����ת��������     Ŀǰ����ģʽ�޸��˸�Ч��

motor_ctrl_type BLDC_motor;
void motor_hall_callback(uint32_t time);

/* ��ʼ���������,Ĭ������ģʽ */
void motor_init(void)       
{
    memset(&BLDC_motor, 0, sizeof(motor_ctrl_type));
    
    BLDC_motor.pBspMotor = bspMotor_init();
    bspMotor_setHallcallback(motor_hall_callback); // ����hall�ص�
    
    BLDC_motor.workType = MOTOR_TORQUE;
    BLDC_motor.state = MOTOR_READY;
    BLDC_motor.err = MOTOR_NOERR;
    
    BLDC_motor.pwmVal = 0;
    BLDC_motor.maxPwmVal = 1000;
    
    BLDC_motor.StallTime = MOTOR_STALL_TIME;
    
    BLDC_motor.setSpeed = 0;
    BLDC_motor.maxSpeed = MOTOR_MAX_SPEED;
    
    BLDC_motor.motorPID.Proportion = 0.005;
    BLDC_motor.motorPID.Integral = 0.001;
    BLDC_motor.motorPID.Derivative = 0.0;
    
    BLDC_motor.setPwm = 0;
}

/* ������� */
void motor_start(void)
{
    if(BLDC_motor.workType == MOTOR_SPEED)
    {
        if(BLDC_motor.setSpeed >= BLDC_motor.maxSpeed / 100 && BLDC_motor.state == MOTOR_READY)
        {
            BLDC_motor.state = MOTOR_START;
            BLDC_motor.StallCnt = 0;
            motor_setStartDuty(100);
            BLDC_motor.err = MOTOR_NOERR;
            bspMotor_start();
            
            // ����BLDC��PID����
            BLDC_motor.motorPID.SetPoint = BLDC_motor.setSpeed;
            BLDC_motor.motorPID.LastError = 0;
            BLDC_motor.motorPID.PrevError = 0;
        }
        else
        {
            BLDC_motor.err = MOTOR_SPEED_TOO_LOW;
        }
    }
    else
    {
        BLDC_motor.state = MOTOR_RUNNING;
        BLDC_motor.StallCnt = 0;
        
        motor_setStartDuty(BLDC_motor.setPwm);
        bspMotor_start();
    }
}

/* ֹͣ��� */
void motor_stop(void)
{
    bspMotor_stop();
    BLDC_motor.pwmVal = 0;
    
    if(BLDC_motor.workType == MOTOR_SPEED)
    {
        BLDC_motor.setSpeed = 0;
    }
    else
    {
        BLDC_motor.setPwm = 0;
    }
    
    BLDC_motor.state = MOTOR_STOPING;
}  

/* ���� */
void motor_overCurrent(void)
{
    BLDC_motor.err = MOTOR_OVERCURRENT;
}

/* �ڴ�������л����� */
void motor_setDir(uint8_t dir)
{
    if(BLDC_motor.state == MOTOR_READY)
    {
        bspMotor_setDir(dir);
    }
}

/* ��������ռ�ձ� */
void motor_setStartDuty(uint16_t duty)
{
    bspMotor_setStartDuty(duty);
}

/* ���ö�Ӧģʽ */
void motor_setMode(motorWork_type mode)
{
    if(BLDC_motor.state == MOTOR_READY)
    {
        BLDC_motor.workType = mode;
        
        BLDC_motor.setSpeed = 0;
        BLDC_motor.setPwm = 0;
        BLDC_motor.pwmVal =0;
    }
}

/* �������� */
void motor_set_torque(int16_t duty)
{
    int8_t dir = duty > 0? 0 : 1; 
    bspMotor_setDir(dir);
    duty = abs(duty);
   
    if(duty >= MAX_DUTY)
    {
        duty = MAX_DUTY;
    }
    BLDC_motor.setPwm = duty;
    BLDC_motor.pwmVal = BLDC_motor.setPwm;
    
    if(BLDC_motor.state == MOTOR_RUNNING)
    {
        bspMotor_setTorque(duty);
    }
}

/* �趨�ٶȲ��� */
void motor_set_speed(uint16_t speed)
{
    BLDC_motor.setSpeed = speed;
    BLDC_motor.motorPID.SetPoint = BLDC_motor.setSpeed;
}

/* hall�ص� */
void motor_hall_callback(uint32_t time)
{
    BLDC_motor.hallPeriod += time;
    BLDC_motor.hallPulNum ++;
    BLDC_motor.StallCnt = 0;
}

/* ����PID���Ʒ��� */
float motor_increment_pid_ctrl(uint16_t curSpeed)
{
    float curError = BLDC_motor.motorPID.SetPoint - curSpeed;
    float increment = 0;
    
    if((curError > -2) && (curError < 2))
    {
        curError = 0;
    }
    
    increment = BLDC_motor.motorPID.Proportion * (curError - BLDC_motor.motorPID.LastError) +   // Pֵ
                BLDC_motor.motorPID.Integral * (curError) +                                     // Iֵ
                BLDC_motor.motorPID.Derivative * (curError - BLDC_motor.motorPID.LastError * 2 + BLDC_motor.motorPID.PrevError); // Dֵ
    
    BLDC_motor.motorPID.PrevError = BLDC_motor.motorPID.LastError;
    BLDC_motor.motorPID.LastError = curError;
    
    return increment;
}

/* ����PID��õ��������е��ٶ� */
void motor_ctrl_speed(void)
{
    int32_t pwm_increment = (int32_t)motor_increment_pid_ctrl(BLDC_motor.measureSpeed);
    
    if(pwm_increment > 100)    // ��ֹ����̫��
    {
        pwm_increment = 100;   
    }
     
    BLDC_motor.pwmVal += pwm_increment;
    
    if(BLDC_motor.pwmVal > 1000)
    {
        if(pwm_increment < 0)   // ���ڼ�ȥ��������ж�ֹͣ
        {
            BLDC_motor.pwmVal = 0;
        }
        else
        {
            BLDC_motor.pwmVal = 1000;
        }
    }
        
}

/* �ٶ�ģʽ���� */
void motor_speed_handle(uint16_t callTime)
{
    /* ״̬���� */
    switch(BLDC_motor.state)
    {
        case MOTOR_READY:
            break;
        case MOTOR_START:
            if(BLDC_motor.measureSpeed > BLDC_motor.maxSpeed / 100)
            {
                BLDC_motor.state = MOTOR_RUNNING;
            }
            break;
        case MOTOR_RUNNING:
            motor_ctrl_speed();
            break;
        case MOTOR_STOPING:
            if(!BLDC_motor.measureSpeed)
            {
                BLDC_motor.state = MOTOR_READY;
            }
            break;
        default:
            motor_stop();
            BLDC_motor.err = MOTOR_SPEED_CTRLERR;
            break;
    }
}

/* ������ģʽ���� */
void motor_torque_handle(uint16_t callTime)
{
   /* ״̬���� */
    switch(BLDC_motor.state)
    {
        case MOTOR_READY:
            break;
        case MOTOR_START:
            BLDC_motor.state = MOTOR_RUNNING;
            break;
        case MOTOR_RUNNING:
            break;
        case MOTOR_STOPING:
            if(!BLDC_motor.measureSpeed)
            {
                BLDC_motor.state = MOTOR_READY;
            }
            break;
        default:
            motor_stop();
            BLDC_motor.err = MOTOR_TORQUE_CTRLERR;
            break;
    } 
}

/* ��ת���� */
void motor_Stall_handle(uint16_t callTime)
{
    if(BLDC_motor.state > MOTOR_READY && BLDC_motor.state < MOTOR_STOPING)
    {
        /* �ٶȶ�ת���� */
        BLDC_motor.StallCnt += callTime;
        if(BLDC_motor.StallCnt >= BLDC_motor.StallTime)
        {
            motor_stop();
            BLDC_motor.err = MOTOR_NOSPIN;
            
            if(BLDC_motor.pBspMotor->err == 1)
            {
                BLDC_motor.err = MOTOR_HALL_ERR;
            }
        }
    }
}

/* �ٶȼ��㴦�� */
void motor_speedMeasure_handle(uint16_t callTime)
{
    static uint8_t timCnt = 0;
    uint32_t speedTotal = 0;
    static uint16_t speedCache[4] = {0};
    static uint8_t speedCnt = 0;
    
    timCnt += callTime;
    if(timCnt >= 100)
    {
        timCnt = 0;
                          // �ö�ʱ����תȦ��  1�Լ� * 3�� *2������          �ö�ʱ�䳤�� 0.xxs
        speedCache[speedCnt++] = (((float)BLDC_motor.hallPulNum / 6) / ((float)BLDC_motor.hallPeriod / HALL_TIMER_FREQ / 60));
        if(speedCnt >= (sizeof(speedCache) / 2))
        {
            speedCnt = 0;
        }
        speedTotal = speedCache[0] + speedCache[1] + speedCache[2] + speedCache[3];
        BLDC_motor.measureSpeed = speedTotal >> 2;
       
        BLDC_motor.hallPulNum = 0;
        BLDC_motor.hallPeriod = 0;
    }
}

/* ����������� */
void motor_drive(uint16_t callTime)
{
    /* ת�ټ��� 100ms����һ�� */
    motor_speedMeasure_handle(callTime);
    
    /* ��ת���� */
    motor_Stall_handle(callTime);
    
    /* ��Ӧ���д��� */
    if(BLDC_motor.workType == MOTOR_SPEED)
    {
        motor_speed_handle(callTime);
    }
    else
    {
        motor_torque_handle(callTime);
    }
    
    /* ���ö�Ӧpwm */
    if(BLDC_motor.state == MOTOR_RUNNING)
    {
        bspMotor_setRunDuty(BLDC_motor.pwmVal);
    }
}

uint16_t motor_get_err(void)
{
    return BLDC_motor.err;
}

uint16_t motor_get_state(void)
{
    return BLDC_motor.state;
}
