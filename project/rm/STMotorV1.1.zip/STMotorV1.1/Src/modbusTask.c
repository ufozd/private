#include "modbusTask.h"
#include "main.h"
#include "cmsis_os.h"
#include "rMB_Slave_Drv.h"
#include "motor_ctrl.h"

#define SlaveUart huart1

static void modbusTask_running(void const * argument);

extern UART_HandleTypeDef huart1;
extern uint8_t writeFlag;
extern uint16_t slavereg[100];

osThreadId modbusTask_id;
osThreadDef(modbusTask, modbusTask_running, osPriorityNormal, 0, 256);
rMB_slave_type mbSlave;
uint8_t SlaveUartRx;

void modbus_open_gate(void)
{
    HAL_GPIO_WritePin(RE485_GPIO_Port, RE485_Pin, GPIO_PIN_SET);
    for(uint8_t i = 0; i < 10; i++)
    {
        __nop();
    }
    
}

void modbus_close_gate(void)
{
    HAL_GPIO_WritePin(RE485_GPIO_Port, RE485_Pin, GPIO_PIN_RESET);
}

uint8_t modbus_slave_send(uint8_t *pData, uint16_t len)
{
    modbus_open_gate();
    if(HAL_OK == HAL_UART_Transmit_IT(&SlaveUart, pData, len))
    {
        return 1;
    }
    return 0;
}

void modbusTask_init(void)
{
    rMB_slave_init(&mbSlave, modbus_slave_send, SLAVE_ADDR, 20, 2);
    modbus_close_gate();
    HAL_UART_Receive_IT(&SlaveUart, &SlaveUartRx, 1);
    modbusTask_id = osThreadCreate(osThread(modbusTask), NULL);
}

void modbusTask_running(void const * argument)
{
    while(1)
    {
        osDelay(1);
        rMB_slave_drv_1ms(&mbSlave);
        
        if(writeFlag)
        {
            writeFlag = 0;
            
            int16_t *data = (int16_t *)&slavereg[21];
            motor_set_torque(*data);
            
            //���д���
            if(slavereg[20] == 1)
            {
                motor_start();
            }
            else if(slavereg[20] == 2)
            {
                motor_stop();
            }                
            slavereg[20] = 0;
        }
    }
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if(huart == &SlaveUart)
    {
        rMB_slave_send_complete_api(&mbSlave);
        modbus_close_gate();
    }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    
    if(huart == &SlaveUart)
    {
        rMB_slave_receive_interrupt_api(&mbSlave, SlaveUartRx);
        HAL_UART_Receive_IT(&SlaveUart, &SlaveUartRx, 1);    
    }
}

