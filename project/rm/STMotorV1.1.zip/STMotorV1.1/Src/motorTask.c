#include "motorTask.h"
#include "main.h"
#include "cmsis_os.h"
#include "motor_ctrl.h"
#include "bsp_time.h"

static void motorTask_running(void const * argument);

osThreadId motorTask_id;
osThreadDef(motorTask, motorTask_running, osPriorityNormal, 0, 256);
extern uint16_t slavereg[100];
uint8_t flag_start;
uint8_t flag_stop;

void motor_test(void)
{
    if(flag_start)
    {
        flag_start = 0;
        motor_set_torque(700);
        motor_start();
    }
    
    if(flag_stop)
    {
        flag_stop = 0;
        motor_stop();
    }
}

void motorTask_init(void)
{
    motor_init();
    motorTask_id = osThreadCreate(osThread(motorTask), NULL);
}

void motorTask_running(void const * argument)
{
    while(1)
    {
        osDelay(1);
        motor_drive(1);
        motor_test();
        
        slavereg[11] = motor_get_err();
        slavereg[12] = motor_get_state();
    }
}
