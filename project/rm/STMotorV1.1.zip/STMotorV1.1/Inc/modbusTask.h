#ifndef __MODBUSTASK_H__
#define __MODBUSTASK_H__


#ifndef SLAVE_ADDR
   #define SLAVE_ADDR  1
#endif

extern void modbusTask_init(void);

#endif
