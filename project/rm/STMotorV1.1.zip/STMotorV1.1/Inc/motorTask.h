#ifndef __MOTORTASK_H__
#define __MOTORTASK_H__

extern void motorTask_init(void);

#endif

