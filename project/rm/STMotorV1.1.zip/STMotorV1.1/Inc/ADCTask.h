#ifndef __ADCTASK_H__
#define __ADCTASK_H__

#include <stdint.h>

#define ADC_BUFF_SIZE  4
#define ADC_CURRENT_SIZE  512

extern void adcTask_init(void);
extern void HAL_time_get_adc(void);

typedef enum
{
    ADC_TEMP_CHANNEL = 0,
    ADC_VBUS_CHANNEL = 1,
    ADC_IA_CHANNEL = 2,
    ADC_IB_CHANNEL = 3,
    ADC_IC_CHANNEL = 4,
}ADC_CHANNEL_type;

typedef struct
{
    int32_t adcTemp[ADC_BUFF_SIZE];
    int32_t adcBus[ADC_BUFF_SIZE];
    int32_t adcia[ADC_CURRENT_SIZE];
    int32_t adcib[ADC_CURRENT_SIZE];
    int32_t adcic[ADC_CURRENT_SIZE];
    
    float temple;
    float vbus;
    float ia;
    float ib;
    float ic;
    
    uint8_t sampleCnt;
    uint16_t currentCnt;
    
    int32_t ia_zero;
    int32_t ib_zero;
    int32_t ic_zero;
}adcTaskData;



#endif
