#ifndef __RMB_SLAVE_HANDLE_H__
#define __RMB_SLAVE_HANDLE_H__

#include "rMB_Slave_Drv.h"

/* �ж��Ƿ��ڴ�����*/
#define RMB_IS_HANDLE						(handle->state.Handle)

/* ����֡��ָ�� */
#define RMB_MODBUS_FUNC					    (handle->ADU.PDU.instructions)

/* ��ȡCRC���� */
#define RMB_GET_RECEIVE_CRC16               (handle->ADU.PDU.data[handle->state.receive_len - 4] << 8 |  \
                                             handle->ADU.PDU.data[handle->state.receive_len - 3] )

/* ��д���ּĴ����� */
#define RMB_GET_KEEPREG_ADDR		       (handle->ADU.PDU.data[0] << 8 | handle->ADU.PDU.data[1])		
#define RMB_GET_KEEPREG_SIZE               (handle->ADU.PDU.data[2] << 8 | handle->ADU.PDU.data[3])	

/* ����Ȧ�� */
#define RMB_GET_COIL_ADDR                  (handle->ADU.PDU.data[0] << 8 | handle->ADU.PDU.data[1])	
#define RMB_GET_COIL_SIZE                  (handle->ADU.PDU.data[2] << 8 | handle->ADU.PDU.data[3])	
#define RMB_GET_COIL_VAL                   (handle->ADU.PDU.data[2] << 8 | handle->ADU.PDU.data[3])

/* ��λ�� */
#define RMB_SET_BIT(add,offosize,status)    if(status)                           \
                                            {                                    \
                                                add |= (0x01 << offosize);       \
                                            }                                    \
                                            else                                 \
                                            {                                    \
                                                add &= ~(0x01 << offosize);      \
                                            }
																	  
																																								
extern void rMB_receive_handle(rMB_slave_type *handle);

																					
#endif

