#ifndef __RMB_CRC_H__
#define __RMB_CRC_H__

#include <stdint.h>

extern uint16_t rMBcrc16(uint8_t *pData, uint16_t length);

#endif

