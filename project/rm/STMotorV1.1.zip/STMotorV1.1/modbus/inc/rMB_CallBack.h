#ifndef __RMB_CALLBACK_H__
#define __RMB_CALLBACK_H__

#include <stdint.h>
#include <string.h>

/* �ӻ���Ȧ�ص����� */
extern uint8_t *rMB_read_coil_callback_slave(uint8_t SlaveID, uint16_t addr, uint16_t size);
extern uint8_t *rMB_write_one_coil_callback_slave(uint8_t SlaveID, uint16_t addr);
extern uint8_t *rMB_write_complex_coil_callback_slave(uint8_t SlaveID, uint16_t addr, uint16_t size);

/* �ӻ����ּĴ����ص����� */
extern uint8_t *rMB_read_keepreg_callback_slave(uint8_t SlaveID, uint16_t addr, uint16_t size);
extern uint8_t *rMB_write_one_keepreg_callback_slave(uint8_t SlaveID, uint16_t addr);
extern uint8_t *rMB_write_complex_keepreg_callback_slave(uint8_t SlaveID, uint16_t addr, uint16_t size);

/* �������Ĵ����ص����� */
extern uint8_t * rMB_read_keepreg_callback_master(uint8_t MasterID, uint16_t addr, uint16_t size);

#endif

